// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from com_interfaces:srv/SiemensPlcCmdInterface.idl
// generated code does not contain a copyright notice

#ifndef COM_INTERFACES__SRV__DETAIL__SIEMENS_PLC_CMD_INTERFACE__TYPE_SUPPORT_H_
#define COM_INTERFACES__SRV__DETAIL__SIEMENS_PLC_CMD_INTERFACE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "com_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_com_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  com_interfaces,
  srv,
  SiemensPlcCmdInterface_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_com_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  com_interfaces,
  srv,
  SiemensPlcCmdInterface_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_com_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  com_interfaces,
  srv,
  SiemensPlcCmdInterface
)();

#ifdef __cplusplus
}
#endif

#endif  // COM_INTERFACES__SRV__DETAIL__SIEMENS_PLC_CMD_INTERFACE__TYPE_SUPPORT_H_
