// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from com_interfaces:msg/AgvControl.idl
// generated code does not contain a copyright notice
#include "com_interfaces/msg/detail/agv_control__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `ip`
// Member `nick_name`
// Member `desc`
#include "rosidl_runtime_c/string_functions.h"

bool
com_interfaces__msg__AgvControl__init(com_interfaces__msg__AgvControl * msg)
{
  if (!msg) {
    return false;
  }
  // locked
  // ip
  if (!rosidl_runtime_c__String__init(&msg->ip)) {
    com_interfaces__msg__AgvControl__fini(msg);
    return false;
  }
  // port
  // type
  // nick_name
  if (!rosidl_runtime_c__String__init(&msg->nick_name)) {
    com_interfaces__msg__AgvControl__fini(msg);
    return false;
  }
  // time
  // desc
  if (!rosidl_runtime_c__String__init(&msg->desc)) {
    com_interfaces__msg__AgvControl__fini(msg);
    return false;
  }
  return true;
}

void
com_interfaces__msg__AgvControl__fini(com_interfaces__msg__AgvControl * msg)
{
  if (!msg) {
    return;
  }
  // locked
  // ip
  rosidl_runtime_c__String__fini(&msg->ip);
  // port
  // type
  // nick_name
  rosidl_runtime_c__String__fini(&msg->nick_name);
  // time
  // desc
  rosidl_runtime_c__String__fini(&msg->desc);
}

bool
com_interfaces__msg__AgvControl__are_equal(const com_interfaces__msg__AgvControl * lhs, const com_interfaces__msg__AgvControl * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // locked
  if (lhs->locked != rhs->locked) {
    return false;
  }
  // ip
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->ip), &(rhs->ip)))
  {
    return false;
  }
  // port
  if (lhs->port != rhs->port) {
    return false;
  }
  // type
  if (lhs->type != rhs->type) {
    return false;
  }
  // nick_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->nick_name), &(rhs->nick_name)))
  {
    return false;
  }
  // time
  if (lhs->time != rhs->time) {
    return false;
  }
  // desc
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->desc), &(rhs->desc)))
  {
    return false;
  }
  return true;
}

bool
com_interfaces__msg__AgvControl__copy(
  const com_interfaces__msg__AgvControl * input,
  com_interfaces__msg__AgvControl * output)
{
  if (!input || !output) {
    return false;
  }
  // locked
  output->locked = input->locked;
  // ip
  if (!rosidl_runtime_c__String__copy(
      &(input->ip), &(output->ip)))
  {
    return false;
  }
  // port
  output->port = input->port;
  // type
  output->type = input->type;
  // nick_name
  if (!rosidl_runtime_c__String__copy(
      &(input->nick_name), &(output->nick_name)))
  {
    return false;
  }
  // time
  output->time = input->time;
  // desc
  if (!rosidl_runtime_c__String__copy(
      &(input->desc), &(output->desc)))
  {
    return false;
  }
  return true;
}

com_interfaces__msg__AgvControl *
com_interfaces__msg__AgvControl__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  com_interfaces__msg__AgvControl * msg = (com_interfaces__msg__AgvControl *)allocator.allocate(sizeof(com_interfaces__msg__AgvControl), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(com_interfaces__msg__AgvControl));
  bool success = com_interfaces__msg__AgvControl__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
com_interfaces__msg__AgvControl__destroy(com_interfaces__msg__AgvControl * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    com_interfaces__msg__AgvControl__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
com_interfaces__msg__AgvControl__Sequence__init(com_interfaces__msg__AgvControl__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  com_interfaces__msg__AgvControl * data = NULL;

  if (size) {
    data = (com_interfaces__msg__AgvControl *)allocator.zero_allocate(size, sizeof(com_interfaces__msg__AgvControl), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = com_interfaces__msg__AgvControl__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        com_interfaces__msg__AgvControl__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
com_interfaces__msg__AgvControl__Sequence__fini(com_interfaces__msg__AgvControl__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      com_interfaces__msg__AgvControl__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

com_interfaces__msg__AgvControl__Sequence *
com_interfaces__msg__AgvControl__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  com_interfaces__msg__AgvControl__Sequence * array = (com_interfaces__msg__AgvControl__Sequence *)allocator.allocate(sizeof(com_interfaces__msg__AgvControl__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = com_interfaces__msg__AgvControl__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
com_interfaces__msg__AgvControl__Sequence__destroy(com_interfaces__msg__AgvControl__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    com_interfaces__msg__AgvControl__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
com_interfaces__msg__AgvControl__Sequence__are_equal(const com_interfaces__msg__AgvControl__Sequence * lhs, const com_interfaces__msg__AgvControl__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!com_interfaces__msg__AgvControl__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
com_interfaces__msg__AgvControl__Sequence__copy(
  const com_interfaces__msg__AgvControl__Sequence * input,
  com_interfaces__msg__AgvControl__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(com_interfaces__msg__AgvControl);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    com_interfaces__msg__AgvControl * data =
      (com_interfaces__msg__AgvControl *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!com_interfaces__msg__AgvControl__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          com_interfaces__msg__AgvControl__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!com_interfaces__msg__AgvControl__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
