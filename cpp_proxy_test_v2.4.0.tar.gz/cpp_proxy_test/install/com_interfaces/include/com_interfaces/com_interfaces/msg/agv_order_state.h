// generated from rosidl_generator_c/resource/idl.h.em
// with input from com_interfaces:msg/AgvOrderState.idl
// generated code does not contain a copyright notice

#ifndef COM_INTERFACES__MSG__AGV_ORDER_STATE_H_
#define COM_INTERFACES__MSG__AGV_ORDER_STATE_H_

#include "com_interfaces/msg/detail/agv_order_state__struct.h"
#include "com_interfaces/msg/detail/agv_order_state__functions.h"
#include "com_interfaces/msg/detail/agv_order_state__type_support.h"

#endif  // COM_INTERFACES__MSG__AGV_ORDER_STATE_H_
