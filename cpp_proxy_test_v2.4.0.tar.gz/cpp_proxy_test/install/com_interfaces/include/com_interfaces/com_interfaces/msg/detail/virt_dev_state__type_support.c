// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from com_interfaces:msg/VirtDevState.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "com_interfaces/msg/detail/virt_dev_state__rosidl_typesupport_introspection_c.h"
#include "com_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "com_interfaces/msg/detail/virt_dev_state__functions.h"
#include "com_interfaces/msg/detail/virt_dev_state__struct.h"


// Include directives for member types
// Member `name`
// Member `err_msg`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  com_interfaces__msg__VirtDevState__init(message_memory);
}

void com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_fini_function(void * message_memory)
{
  com_interfaces__msg__VirtDevState__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_member_array[3] = {
  {
    "name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(com_interfaces__msg__VirtDevState, name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "err_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(com_interfaces__msg__VirtDevState, err_code),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "err_msg",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(com_interfaces__msg__VirtDevState, err_msg),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_members = {
  "com_interfaces__msg",  // message namespace
  "VirtDevState",  // message name
  3,  // number of fields
  sizeof(com_interfaces__msg__VirtDevState),
  com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_member_array,  // message members
  com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_init_function,  // function to initialize message memory (memory has to be allocated)
  com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_type_support_handle = {
  0,
  &com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_com_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, com_interfaces, msg, VirtDevState)() {
  if (!com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_type_support_handle.typesupport_identifier) {
    com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &com_interfaces__msg__VirtDevState__rosidl_typesupport_introspection_c__VirtDevState_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
